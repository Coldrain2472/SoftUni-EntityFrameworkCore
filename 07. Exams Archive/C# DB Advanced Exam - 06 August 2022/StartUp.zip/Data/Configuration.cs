﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-85U9SF9\SQLEXPRESS;Database=FootballersExam;Trusted_Connection=True";
    }
}
