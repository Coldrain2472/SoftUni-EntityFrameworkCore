﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-85U9SF9\SQLEXPRESS;Database=Trucks;Trusted_Connection=True";
    }
}