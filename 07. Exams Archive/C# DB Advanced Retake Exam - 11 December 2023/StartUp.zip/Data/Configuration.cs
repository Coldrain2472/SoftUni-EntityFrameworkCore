﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-85U9SF9\SQLEXPRESS;Database=Cadastre;Integrated Security=True;Encrypt=False;";
    }
}
