﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-85U9SF9\SQLEXPRESS;Database=Invoices;Integrated Security=True;Encrypt=False";
    }
}
