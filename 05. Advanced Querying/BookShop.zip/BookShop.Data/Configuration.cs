﻿namespace BookShop.Data;

internal class Configuration
{
    internal static string ConnectionString
        => @"Server=DESKTOP-85U9SF9\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
}
